# CallShield AI — local + Gemini scam-risk prototype

## Features
- Browser microphone speech recognition (Chrome/Edge; language can be selected as English India, Telugu, or Hindi).
- Local multilingual phrase rules that keep working without Gemini.
- Optional Gemini contextual analysis through a server-side API key.
- Manual text testing and a simulated scam demo.
- The UI is a prototype, not a cellular-call interceptor or automatic police complaint system.

## Requirements
- Windows 10/11
- Node.js 20+ (Node 22 LTS recommended) and npm
- Chrome or Microsoft Edge for browser speech recognition

## Setup (Windows PowerShell)
1. Extract this ZIP to a simple folder such as `C:\CallShieldAI`.
2. Open that folder in VS Code.
3. Open Terminal → New Terminal (PowerShell).
4. Run `node -v` and `npm -v`. If either is not found, install Node.js LTS from https://nodejs.org/ and restart VS Code.
5. Install dependencies: `npm install`
6. Copy the sample environment file: `Copy-Item .env.example .env`
7. Open `.env` and replace the placeholder with your Gemini API key from https://aistudio.google.com/apikey. Keep the key private. If you want offline/local-only mode, leave the placeholder unchanged.
8. Start the app: `npm start`
9. Open **http://localhost:3000** in Chrome or Edge. Do not open `index.html` directly or use Live Server; the frontend needs the Express API on the same origin.
10. Accept microphone permission when prompted. Select the language before pressing **START LIVE LISTENING**. Browser speech recognition may require internet and support varies by browser.
11. For a repeatable test, answer the simulated call and press **PLAY SCAM DEMO**, or type English/Telugu/Hindi text into the manual test box and click **ANALYZE TEXT**.

## API checks
- Open http://localhost:3000/api/health — should return `ok: true` and indicate whether a key is configured.
- Test analysis in PowerShell:
  `Invoke-RestMethod -Uri http://localhost:3000/api/analyze -Method Post -ContentType 'application/json' -Body '{"transcript":"Please tell me your OTP immediately or your account will be blocked"}'`
- If Gemini fails, the page keeps local risk scoring and shows the failure in the status line. Check the key, quota, internet connection, and model ID.

## Security and limitations
- `.env` is ignored by Git. Never paste API keys into browser code or commit them. Rotate any key accidentally shared in a ZIP/repository.
- Transcripts are sent to Gemini only when a key is configured and a phrase is analyzed; avoid real sensitive/private calls during testing.
- Keyword rules can miss scams and can flag benign phrases. Scores are heuristics, not calibrated probabilities or legal findings. Verify suspicious requests via a trusted official channel.
- Browser microphone access does not provide access to cellular call audio. Automatic reporting, call recording, and police/cybercrime submission are not implemented.
